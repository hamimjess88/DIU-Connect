"use client"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Gamepad2, Users } from "lucide-react"
import Image from "next/image"

const games = [
  {
    id: 1,
    title: "DIU Trivia Challenge",
    description: "Test your knowledge about DIU with this fun trivia game",
    image: "/placeholder.svg?height=200&width=300",
    players: 1243,
    difficulty: "Medium",
  },
  {
    id: 2,
    title: "Campus Runner",
    description: "Race through campus avoiding obstacles and collecting points",
    image: "/placeholder.svg?height=200&width=300",
    players: 987,
    difficulty: "Easy",
  },
  {
    id: 3,
    title: "Professor Guess Who",
    description: "Guess which professor is being described by the clues",
    image: "/placeholder.svg?height=200&width=300",
    players: 756,
    difficulty: "Hard",
  },
]

export default function GameSection() {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {games.map((game) => (
        <Card key={game.id} className="overflow-hidden flex flex-col">
          <div className="relative aspect-[3/2] w-full">
            <Image src={game.image || "/placeholder.svg"} alt={game.title} fill className="object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4">
              <h3 className="text-xl font-bold text-white">{game.title}</h3>
              <p className="text-sm text-white/80">{game.difficulty} Difficulty</p>
            </div>
          </div>
          <CardContent className="flex-1 p-4">
            <p className="text-sm text-muted-foreground">{game.description}</p>
          </CardContent>
          <CardFooter className="p-4 pt-0 flex justify-between">
            <div className="flex items-center text-sm text-muted-foreground">
              <Users className="mr-1 h-4 w-4" />
              <span>{game.players} players</span>
            </div>
            <Button size="sm">Play Now</Button>
          </CardFooter>
        </Card>
      ))}

      <Card className="overflow-hidden flex flex-col bg-primary/10 border-dashed">
        <CardContent className="flex-1 p-6 flex flex-col items-center justify-center text-center gap-4">
          <div className="rounded-full bg-primary/20 p-3">
            <Gamepad2 className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Suggest a Game</h3>
            <p className="text-sm text-muted-foreground mt-1">Have a fun game idea for the DIU community?</p>
          </div>
          <Button variant="outline">Submit Your Idea</Button>
        </CardContent>
      </Card>
    </div>
  )
}

