"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { ThumbsUp, MessageSquare, Share2 } from "lucide-react"
import Image from "next/image"

const initialMemes = [
  {
    id: 1,
    user: {
      name: "Rahul Ahmed",
      avatar: "/placeholder.svg?height=40&width=40",
      handle: "rahul_a",
    },
    content: "When the professor says 'This won't be on the exam' but it's the entire exam",
    image: "/placeholder.svg?height=400&width=600",
    likes: 245,
    comments: 32,
    shares: 12,
    time: "2 hours ago",
    liked: false,
  },
  {
    id: 2,
    user: {
      name: "Priya Khan",
      avatar: "/placeholder.svg?height=40&width=40",
      handle: "priya_k",
    },
    content: "DIU cafeteria food be like...",
    image: "/placeholder.svg?height=400&width=600",
    likes: 189,
    comments: 45,
    shares: 8,
    time: "5 hours ago",
    liked: false,
  },
  {
    id: 3,
    user: {
      name: "Farhan Islam",
      avatar: "/placeholder.svg?height=40&width=40",
      handle: "farhan_i",
    },
    content: "When you realize you have 5 assignments due tomorrow and you haven't started any",
    image: "/placeholder.svg?height=400&width=600",
    likes: 320,
    comments: 67,
    shares: 24,
    time: "Yesterday",
    liked: false,
  },
]

export default function MemeFeed() {
  const [memes, setMemes] = useState(initialMemes)

  const handleLike = (id: number) => {
    setMemes(
      memes.map((meme) => {
        if (meme.id === id) {
          return {
            ...meme,
            likes: meme.liked ? meme.likes - 1 : meme.likes + 1,
            liked: !meme.liked,
          }
        }
        return meme
      }),
    )
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {memes.map((meme) => (
        <Card key={meme.id} className="overflow-hidden">
          <CardHeader className="p-4">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarImage src={meme.user.avatar} alt={meme.user.name} />
                <AvatarFallback>{meme.user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-semibold">{meme.user.name}</div>
                <div className="text-xs text-muted-foreground">
                  @{meme.user.handle} • {meme.time}
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="px-4 pb-3">
              <p>{meme.content}</p>
            </div>
            <div className="relative aspect-video w-full">
              <Image src={meme.image || "/placeholder.svg"} alt="Meme" fill className="object-cover" />
            </div>
          </CardContent>
          <CardFooter className="p-4 flex justify-between">
            <Button
              variant="ghost"
              size="sm"
              className={`gap-1 ${meme.liked ? "text-primary" : ""}`}
              onClick={() => handleLike(meme.id)}
            >
              <ThumbsUp className="h-4 w-4" />
              <span>{meme.likes}</span>
            </Button>
            <Button variant="ghost" size="sm" className="gap-1">
              <MessageSquare className="h-4 w-4" />
              <span>{meme.comments}</span>
            </Button>
            <Button variant="ghost" size="sm" className="gap-1">
              <Share2 className="h-4 w-4" />
              <span>{meme.shares}</span>
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

