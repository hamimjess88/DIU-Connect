"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Download, FileText, Users, BookOpen, Video, Calendar, Plus, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

type Resource = {
  id: number
  title: string
  type: "notes" | "book" | "video" | "past-paper" | "assignment"
  subject: string
  semester: string
  uploadedBy: {
    name: string
    avatar: string
  }
  uploadDate: string
  downloads: number
  fileSize: string
  fileType: string
}

type StudyGroup = {
  id: number
  name: string
  subject: string
  members: number
  nextMeeting?: string
  avatar: string
}

const resources: Resource[] = [
  {
    id: 1,
    title: "Data Structures and Algorithms Complete Notes",
    type: "notes",
    subject: "CSE 2101",
    semester: "4th",
    uploadedBy: {
      name: "Fahim Rahman",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    uploadDate: "July 15, 2023",
    downloads: 342,
    fileSize: "4.2 MB",
    fileType: "PDF",
  },
  {
    id: 2,
    title: "Database Management Systems Lecture Videos",
    type: "video",
    subject: "CSE 3201",
    semester: "5th",
    uploadedBy: {
      name: "Dr. Akram Khan",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    uploadDate: "June 28, 2023",
    downloads: 187,
    fileSize: "1.2 GB",
    fileType: "MP4",
  },
  {
    id: 3,
    title: "Software Engineering Past Papers (2018-2022)",
    type: "past-paper",
    subject: "CSE 3105",
    semester: "6th",
    uploadedBy: {
      name: "Nusrat Jahan",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    uploadDate: "May 10, 2023",
    downloads: 523,
    fileSize: "8.5 MB",
    fileType: "ZIP",
  },
  {
    id: 4,
    title: "Artificial Intelligence Textbook",
    type: "book",
    subject: "CSE 4107",
    semester: "7th",
    uploadedBy: {
      name: "Library Resources",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    uploadDate: "April 5, 2023",
    downloads: 289,
    fileSize: "12.8 MB",
    fileType: "PDF",
  },
]

const studyGroups: StudyGroup[] = [
  {
    id: 1,
    name: "Algorithm Masters",
    subject: "Data Structures & Algorithms",
    members: 28,
    nextMeeting: "August 12, 2023 • 5:00 PM",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 2,
    name: "Web Dev Wizards",
    subject: "Web Development",
    members: 35,
    nextMeeting: "August 15, 2023 • 6:30 PM",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 3,
    name: "Database Design Group",
    subject: "Database Management Systems",
    members: 22,
    nextMeeting: "August 10, 2023 • 4:00 PM",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 4,
    name: "AI Enthusiasts",
    subject: "Artificial Intelligence",
    members: 18,
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

export default function StudyResources() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredResources = resources.filter(
    (resource) =>
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.subject.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getResourceIcon = (type: Resource["type"]) => {
    switch (type) {
      case "notes":
        return <FileText className="h-5 w-5 text-blue-500" />
      case "book":
        return <BookOpen className="h-5 w-5 text-green-500" />
      case "video":
        return <Video className="h-5 w-5 text-red-500" />
      case "past-paper":
        return <FileText className="h-5 w-5 text-amber-500" />
      case "assignment":
        return <FileText className="h-5 w-5 text-purple-500" />
      default:
        return <FileText className="h-5 w-5" />
    }
  }

  return (
    <Tabs defaultValue="resources">
      <TabsList className="mb-4">
        <TabsTrigger value="resources">Study Materials</TabsTrigger>
        <TabsTrigger value="groups">Study Groups</TabsTrigger>
      </TabsList>

      <TabsContent value="resources">
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search resources by title or course code..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="grid gap-4">
          {filteredResources.map((resource) => (
            <Card key={resource.id}>
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className="rounded-md bg-primary/10 p-2">{getResourceIcon(resource.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">{resource.title}</h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>{resource.subject}</span>
                          <span>•</span>
                          <span>{resource.semester} Semester</span>
                        </div>
                      </div>
                      <Badge variant="outline">{resource.fileType}</Badge>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={resource.uploadedBy.avatar} alt={resource.uploadedBy.name} />
                          <AvatarFallback>{resource.uploadedBy.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="text-sm">
                          <span>{resource.uploadedBy.name}</span>
                          <span className="text-muted-foreground"> • {resource.uploadDate}</span>
                        </div>
                      </div>
                      <Button size="sm" className="gap-1">
                        <Download className="h-4 w-4" />
                        <span>{resource.downloads}</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-4 flex justify-center">
          <Button variant="outline" className="gap-1">
            <Plus className="h-4 w-4" />
            Upload Study Material
          </Button>
        </div>
      </TabsContent>

      <TabsContent value="groups">
        <div className="grid gap-4 md:grid-cols-2">
          {studyGroups.map((group) => (
            <Card key={group.id}>
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={group.avatar} alt={group.name} />
                    <AvatarFallback>{group.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-medium">{group.name}</h3>
                    <div className="text-sm text-muted-foreground">{group.subject}</div>
                    <div className="mt-1 flex items-center gap-4">
                      <div className="flex items-center gap-1 text-sm">
                        <Users className="h-3.5 w-3.5 text-muted-foreground" />
                        <span>{group.members} members</span>
                      </div>
                      {group.nextMeeting && (
                        <div className="flex items-center gap-1 text-sm">
                          <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                          <span>{group.nextMeeting}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <Button size="sm">Join</Button>
                </div>
              </CardContent>
            </Card>
          ))}

          <Card className="bg-primary/10 border-dashed">
            <CardContent className="p-4 flex items-center justify-center">
              <Button variant="ghost" className="gap-2 h-12">
                <Plus className="h-4 w-4" />
                Create Study Group
              </Button>
            </CardContent>
          </Card>
        </div>
      </TabsContent>
    </Tabs>
  )
}

