"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

type PollOption = {
  id: number
  text: string
  votes: number
  selected?: boolean
}

type Poll = {
  id: number
  question: string
  options: PollOption[]
  totalVotes: number
  voted: boolean
  author: {
    name: string
    avatar: string
  }
  timeRemaining: string
}

const initialPolls: Poll[] = [
  {
    id: 1,
    question: "Which cafeteria on campus has the best food?",
    options: [
      { id: 1, text: "Main Building Cafeteria", votes: 145 },
      { id: 2, text: "Engineering Building Cafe", votes: 89 },
      { id: 3, text: "Business Faculty Canteen", votes: 67 },
      { id: 4, text: "Library Coffee Shop", votes: 120 },
    ],
    totalVotes: 421,
    voted: false,
    author: {
      name: "Student Council",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    timeRemaining: "2 days left",
  },
  {
    id: 2,
    question: "What event would you like to see next semester?",
    options: [
      { id: 1, text: "Tech Hackathon", votes: 230 },
      { id: 2, text: "Cultural Festival", votes: 185 },
      { id: 3, text: "Sports Tournament", votes: 142 },
      { id: 4, text: "Career Fair", votes: 198 },
    ],
    totalVotes: 755,
    voted: false,
    author: {
      name: "Events Committee",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    timeRemaining: "5 days left",
  },
]

export default function PollSection() {
  const [polls, setPolls] = useState(initialPolls)

  const handleVote = (pollId: number, optionId: number) => {
    setPolls(
      polls.map((poll) => {
        if (poll.id === pollId && !poll.voted) {
          const updatedOptions = poll.options.map((option) => {
            if (option.id === optionId) {
              return { ...option, votes: option.votes + 1, selected: true }
            }
            return option
          })

          return {
            ...poll,
            options: updatedOptions,
            totalVotes: poll.totalVotes + 1,
            voted: true,
          }
        }
        return poll
      }),
    )
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {polls.map((poll) => (
        <Card key={poll.id}>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <Avatar>
                <AvatarImage src={poll.author.avatar} alt={poll.author.name} />
                <AvatarFallback>{poll.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-semibold">{poll.author.name}</div>
                <div className="text-xs text-muted-foreground">{poll.timeRemaining}</div>
              </div>
            </div>
            <CardTitle>{poll.question}</CardTitle>
            <CardDescription>{poll.totalVotes} votes so far</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {poll.options.map((option) => {
                const percentage = poll.totalVotes > 0 ? Math.round((option.votes / poll.totalVotes) * 100) : 0

                return (
                  <div key={option.id} className="space-y-2">
                    <div className="flex justify-between">
                      <span className={`text-sm font-medium ${option.selected ? "text-primary" : ""}`}>
                        {option.text}
                      </span>
                      {poll.voted && <span className="text-sm">{percentage}%</span>}
                    </div>
                    {poll.voted ? (
                      <Progress value={percentage} className="h-2" />
                    ) : (
                      <Button
                        variant="outline"
                        className="w-full justify-start h-10 font-normal"
                        onClick={() => handleVote(poll.id, option.id)}
                      >
                        {option.text}
                      </Button>
                    )}
                  </div>
                )
              })}
            </div>
          </CardContent>
          <CardFooter>
            {poll.voted ? (
              <p className="text-sm text-muted-foreground">Thanks for voting!</p>
            ) : (
              <p className="text-sm text-muted-foreground">Select an option to vote</p>
            )}
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

