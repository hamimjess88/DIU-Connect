"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, Users, Bell } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type Event = {
  id: number
  title: string
  date: string
  time: string
  location: string
  category: "academic" | "cultural" | "workshop" | "sports" | "deadline"
  description: string
  attendees?: number
  reminder?: boolean
}

const upcomingEvents: Event[] = [
  {
    id: 1,
    title: "Fall Semester Registration",
    date: "August 15, 2023",
    time: "9:00 AM - 4:00 PM",
    location: "Main Campus, Registration Office",
    category: "deadline",
    description: "Last date to register for Fall 2023 semester courses. Complete your registration and fee payment.",
  },
  {
    id: 2,
    title: "Orientation for New Students",
    date: "August 20, 2023",
    time: "10:00 AM - 1:00 PM",
    location: "Auditorium, Main Building",
    category: "academic",
    description: "Welcome program for newly admitted students. Campus tour and introduction to university facilities.",
    attendees: 350,
    reminder: true,
  },
  {
    id: 3,
    title: "Tech Fest 2023",
    date: "September 5-7, 2023",
    time: "All Day",
    location: "Engineering Building",
    category: "cultural",
    description: "Annual technology festival featuring competitions, workshops, and exhibitions from all departments.",
    attendees: 1200,
  },
  {
    id: 4,
    title: "Career Development Workshop",
    date: "September 12, 2023",
    time: "2:00 PM - 5:00 PM",
    location: "Business Faculty, Room 301",
    category: "workshop",
    description: "Resume building and interview preparation workshop by industry professionals.",
    attendees: 120,
    reminder: true,
  },
  {
    id: 5,
    title: "Inter-University Football Tournament",
    date: "September 18-25, 2023",
    time: "Various Times",
    location: "DIU Sports Complex",
    category: "sports",
    description: "Annual football tournament with teams from universities across the country.",
    attendees: 500,
  },
]

export default function EventCalendar() {
  const [events, setEvents] = useState(upcomingEvents)

  const toggleReminder = (id: number) => {
    setEvents(
      events.map((event) => {
        if (event.id === id) {
          return { ...event, reminder: !event.reminder }
        }
        return event
      }),
    )
  }

  const getCategoryColor = (category: Event["category"]) => {
    switch (category) {
      case "academic":
        return "bg-blue-100 text-blue-800"
      case "cultural":
        return "bg-purple-100 text-purple-800"
      case "workshop":
        return "bg-green-100 text-green-800"
      case "sports":
        return "bg-orange-100 text-orange-800"
      case "deadline":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div>
      <Tabs defaultValue="upcoming">
        <TabsList className="mb-4">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="academic">Academic</TabsTrigger>
          <TabsTrigger value="cultural">Cultural</TabsTrigger>
          <TabsTrigger value="deadlines">Deadlines</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming">
          <div className="grid gap-4 md:grid-cols-2">
            {events.map((event) => (
              <Card key={event.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <Badge className={`${getCategoryColor(event.category)}`}>
                      {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="icon"
                      className={`h-8 w-8 ${event.reminder ? "text-primary" : ""}`}
                      onClick={() => toggleReminder(event.id)}
                    >
                      <Bell className="h-4 w-4" />
                      <span className="sr-only">Set Reminder</span>
                    </Button>
                  </div>
                  <CardTitle className="text-xl">{event.title}</CardTitle>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{event.location}</span>
                    </div>
                    {event.attendees && (
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span>{event.attendees} attending</span>
                      </div>
                    )}
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">{event.description}</p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" size="sm" className="w-full">
                    Add to Calendar
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="academic">
          <div className="grid gap-4 md:grid-cols-2">
            {events
              .filter((event) => event.category === "academic")
              .map((event) => (
                <Card key={event.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <Badge className={`${getCategoryColor(event.category)}`}>
                        {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        className={`h-8 w-8 ${event.reminder ? "text-primary" : ""}`}
                        onClick={() => toggleReminder(event.id)}
                      >
                        <Bell className="h-4 w-4" />
                        <span className="sr-only">Set Reminder</span>
                      </Button>
                    </div>
                    <CardTitle className="text-xl">{event.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{event.location}</span>
                      </div>
                      {event.attendees && (
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span>{event.attendees} attending</span>
                        </div>
                      )}
                    </div>
                    <p className="mt-3 text-sm text-muted-foreground">{event.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      Add to Calendar
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>

        {/* Similar structure for other tabs */}
        <TabsContent value="cultural">
          <div className="grid gap-4 md:grid-cols-2">
            {events
              .filter((event) => event.category === "cultural")
              .map((event) => (
                <Card key={event.id}>
                  {/* Same card structure as above */}
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <Badge className={`${getCategoryColor(event.category)}`}>
                        {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        className={`h-8 w-8 ${event.reminder ? "text-primary" : ""}`}
                        onClick={() => toggleReminder(event.id)}
                      >
                        <Bell className="h-4 w-4" />
                        <span className="sr-only">Set Reminder</span>
                      </Button>
                    </div>
                    <CardTitle className="text-xl">{event.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{event.location}</span>
                      </div>
                      {event.attendees && (
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span>{event.attendees} attending</span>
                        </div>
                      )}
                    </div>
                    <p className="mt-3 text-sm text-muted-foreground">{event.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      Add to Calendar
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="deadlines">
          <div className="grid gap-4 md:grid-cols-2">
            {events
              .filter((event) => event.category === "deadline")
              .map((event) => (
                <Card key={event.id}>
                  {/* Same card structure as above */}
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <Badge className={`${getCategoryColor(event.category)}`}>
                        {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        className={`h-8 w-8 ${event.reminder ? "text-primary" : ""}`}
                        onClick={() => toggleReminder(event.id)}
                      >
                        <Bell className="h-4 w-4" />
                        <span className="sr-only">Set Reminder</span>
                      </Button>
                    </div>
                    <CardTitle className="text-xl">{event.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{event.location}</span>
                      </div>
                      {event.attendees && (
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span>{event.attendees} attending</span>
                        </div>
                      )}
                    </div>
                    <p className="mt-3 text-sm text-muted-foreground">{event.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      Add to Calendar
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

