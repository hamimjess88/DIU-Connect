"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ThumbsUp, MessageSquare, Share2, Bookmark, Eye } from "lucide-react"
import Image from "next/image"

type NewsArticle = {
  id: number
  title: string
  excerpt: string
  content: string
  image: string
  category: "announcement" | "achievement" | "event" | "academic" | "sports"
  author: {
    name: string
    role: string
    avatar: string
  }
  date: string
  views: number
  likes: number
  comments: number
  saved: boolean
  liked: boolean
}

const newsArticles: NewsArticle[] = [
  {
    id: 1,
    title: "DIU Ranks Among Top 10 Universities in National Survey",
    excerpt:
      "Daffodil International University has been ranked among the top 10 universities in the country according to the latest national survey.",
    content:
      "In a remarkable achievement, Daffodil International University has secured a position among the top 10 universities in Bangladesh according to the latest National University Ranking Survey. The ranking, which evaluates institutions based on academic excellence, research output, industry connections, and student satisfaction, places DIU at number 7 nationwide, up from last year's position of 12.",
    image: "/placeholder.svg?height=400&width=600",
    category: "achievement",
    author: {
      name: "University PR Office",
      role: "Official",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    date: "August 5, 2023",
    views: 3245,
    likes: 287,
    comments: 42,
    saved: false,
    liked: false,
  },
  {
    id: 2,
    title: "New Computer Science Curriculum Announced for Fall 2023",
    excerpt:
      "The Department of Computer Science and Engineering has announced a completely revamped curriculum starting from the Fall 2023 semester.",
    content:
      "The Department of Computer Science and Engineering at DIU has unveiled a comprehensive update to its undergraduate curriculum, set to take effect from the Fall 2023 semester. The new curriculum incorporates cutting-edge technologies including artificial intelligence, machine learning, blockchain, and cybersecurity as core components rather than electives.",
    image: "/placeholder.svg?height=400&width=600",
    category: "academic",
    author: {
      name: "Dr. Rahman Khan",
      role: "Head of CSE Department",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    date: "July 28, 2023",
    views: 2187,
    likes: 156,
    comments: 23,
    saved: true,
    liked: true,
  },
  {
    id: 3,
    title: "DIU Robotics Team Wins International Competition in Singapore",
    excerpt:
      "The university's robotics team has brought home the first prize from the International Robotics Challenge held in Singapore last week.",
    content:
      "In a proud moment for Daffodil International University, the DIU Robotics Team has secured the first position at the prestigious International Robotics Challenge held in Singapore. Competing against 45 teams from 23 countries, the DIU team impressed judges with their innovative autonomous rescue robot designed to navigate disaster zones and locate survivors.",
    image: "/placeholder.svg?height=400&width=600",
    category: "achievement",
    author: {
      name: "Student Affairs Office",
      role: "Official",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    date: "July 15, 2023",
    views: 4532,
    likes: 423,
    comments: 87,
    saved: false,
    liked: false,
  },
]

export default function CampusNews() {
  const [news, setNews] = useState(newsArticles)

  const toggleLike = (id: number) => {
    setNews(
      news.map((article) => {
        if (article.id === id) {
          return {
            ...article,
            likes: article.liked ? article.likes - 1 : article.likes + 1,
            liked: !article.liked,
          }
        }
        return article
      }),
    )
  }

  const toggleSave = (id: number) => {
    setNews(
      news.map((article) => {
        if (article.id === id) {
          return {
            ...article,
            saved: !article.saved,
          }
        }
        return article
      }),
    )
  }

  const getCategoryColor = (category: NewsArticle["category"]) => {
    switch (category) {
      case "announcement":
        return "bg-blue-100 text-blue-800"
      case "achievement":
        return "bg-green-100 text-green-800"
      case "event":
        return "bg-purple-100 text-purple-800"
      case "academic":
        return "bg-yellow-100 text-yellow-800"
      case "sports":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {news.map((article) => (
        <Card key={article.id} className="overflow-hidden flex flex-col">
          <div className="relative aspect-video w-full">
            <Image src={article.image || "/placeholder.svg"} alt={article.title} fill className="object-cover" />
            <div className="absolute top-2 left-2">
              <Badge className={`${getCategoryColor(article.category)}`}>
                {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
              </Badge>
            </div>
          </div>
          <CardHeader className="p-4 pb-0">
            <div className="flex items-center gap-2 mb-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={article.author.avatar} alt={article.author.name} />
                <AvatarFallback>{article.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="text-sm">
                <span className="font-medium">{article.author.name}</span>
                <span className="text-muted-foreground"> • {article.date}</span>
              </div>
            </div>
            <CardTitle className="text-xl line-clamp-2">{article.title}</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-2 flex-1">
            <p className="text-muted-foreground line-clamp-3">{article.excerpt}</p>
          </CardContent>
          <CardFooter className="p-4 pt-0 flex justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                className={`gap-1 p-0 h-auto ${article.liked ? "text-primary" : ""}`}
                onClick={() => toggleLike(article.id)}
              >
                <ThumbsUp className="h-4 w-4" />
                <span>{article.likes}</span>
              </Button>
              <Button variant="ghost" size="sm" className="gap-1 p-0 h-auto">
                <MessageSquare className="h-4 w-4" />
                <span>{article.comments}</span>
              </Button>
              <div className="flex items-center gap-1 text-muted-foreground text-sm">
                <Eye className="h-4 w-4" />
                <span>{article.views}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${article.saved ? "text-primary" : ""}`}
                onClick={() => toggleSave(article.id)}
              >
                <Bookmark className="h-4 w-4" />
                <span className="sr-only">Save</span>
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <Share2 className="h-4 w-4" />
                <span className="sr-only">Share</span>
              </Button>
            </div>
          </CardFooter>
        </Card>
      ))}

      <Card className="overflow-hidden flex flex-col bg-primary/10 border-dashed">
        <CardContent className="flex-1 p-6 flex flex-col items-center justify-center text-center gap-4">
          <div className="rounded-full bg-primary/20 p-3">
            <MessageSquare className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Submit News</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Have an important announcement or achievement to share?
            </p>
          </div>
          <Button variant="outline">Submit News Article</Button>
        </CardContent>
      </Card>
    </div>
  )
}

