"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Trophy, Flame, Award } from "lucide-react"

type LeaderboardUser = {
  id: number
  name: string
  avatar: string
  points: number
  badge?: string
  department: string
  semester: string
  rank: number
  change?: "up" | "down" | "same"
}

const weeklyLeaders: LeaderboardUser[] = [
  {
    id: 1,
    name: "Anika Rahman",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 1250,
    badge: "Meme Queen",
    department: "Computer Science",
    semester: "6th",
    rank: 1,
    change: "up",
  },
  {
    id: 2,
    name: "Tanvir Ahmed",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 980,
    badge: "Quiz Master",
    department: "Business Administration",
    semester: "8th",
    rank: 2,
    change: "same",
  },
  {
    id: 3,
    name: "Sadia Khan",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 875,
    badge: "Social Butterfly",
    department: "Electrical Engineering",
    semester: "4th",
    rank: 3,
    change: "up",
  },
  {
    id: 4,
    name: "Rafid Hasan",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 820,
    department: "Architecture",
    semester: "7th",
    rank: 4,
    change: "down",
  },
  {
    id: 5,
    name: "Nusrat Jahan",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 790,
    department: "Pharmacy",
    semester: "5th",
    rank: 5,
    change: "up",
  },
]

const allTimeLeaders: LeaderboardUser[] = [
  {
    id: 1,
    name: "Fahim Rahman",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 15780,
    badge: "Campus Legend",
    department: "Computer Science",
    semester: "8th",
    rank: 1,
    change: "same",
  },
  {
    id: 2,
    name: "Anika Rahman",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 12450,
    badge: "Meme Queen",
    department: "Computer Science",
    semester: "6th",
    rank: 2,
    change: "up",
  },
  {
    id: 3,
    name: "Mahir Khan",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 11230,
    badge: "Game Champion",
    department: "Electrical Engineering",
    semester: "8th",
    rank: 3,
    change: "down",
  },
  {
    id: 4,
    name: "Lamia Akter",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 9870,
    badge: "Quiz Master",
    department: "Business Administration",
    semester: "7th",
    rank: 4,
    change: "same",
  },
  {
    id: 5,
    name: "Tanvir Ahmed",
    avatar: "/placeholder.svg?height=40&width=40",
    points: 8940,
    department: "Business Administration",
    semester: "8th",
    rank: 5,
    change: "up",
  },
]

export default function Leaderboard() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-primary" />
          Student Leaderboard
        </CardTitle>
        <CardDescription>Top contributors based on activity, engagement, and community impact</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="weekly">
          <TabsList className="mb-4">
            <TabsTrigger value="weekly">This Week</TabsTrigger>
            <TabsTrigger value="alltime">All Time</TabsTrigger>
          </TabsList>
          <TabsContent value="weekly">
            <div className="space-y-4">
              {weeklyLeaders.map((user) => (
                <div key={user.id} className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-8">
                    {user.rank === 1 ? (
                      <Trophy className="h-6 w-6 text-yellow-500" />
                    ) : user.rank === 2 ? (
                      <Trophy className="h-6 w-6 text-gray-400" />
                    ) : user.rank === 3 ? (
                      <Trophy className="h-6 w-6 text-amber-700" />
                    ) : (
                      <span className="text-lg font-bold">{user.rank}</span>
                    )}
                  </div>
                  <Avatar className="h-10 w-10 border">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center">
                      <span className="font-medium">{user.name}</span>
                      {user.badge && (
                        <Badge variant="outline" className="ml-2 text-xs">
                          {user.badge}
                        </Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {user.department}, {user.semester} Semester
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Flame className="h-4 w-4 text-primary" />
                    <span className="font-medium">{user.points}</span>
                  </div>
                  <div className="w-6 text-right">
                    {user.change === "up" ? (
                      <span className="text-green-500">↑</span>
                    ) : user.change === "down" ? (
                      <span className="text-red-500">↓</span>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="alltime">
            <div className="space-y-4">
              {allTimeLeaders.map((user) => (
                <div key={user.id} className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-8">
                    {user.rank === 1 ? (
                      <Trophy className="h-6 w-6 text-yellow-500" />
                    ) : user.rank === 2 ? (
                      <Trophy className="h-6 w-6 text-gray-400" />
                    ) : user.rank === 3 ? (
                      <Trophy className="h-6 w-6 text-amber-700" />
                    ) : (
                      <span className="text-lg font-bold">{user.rank}</span>
                    )}
                  </div>
                  <Avatar className="h-10 w-10 border">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center">
                      <span className="font-medium">{user.name}</span>
                      {user.badge && (
                        <Badge variant="outline" className="ml-2 text-xs">
                          {user.badge}
                        </Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {user.department}, {user.semester} Semester
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Award className="h-4 w-4 text-primary" />
                    <span className="font-medium">{user.points}</span>
                  </div>
                  <div className="w-6 text-right">
                    {user.change === "up" ? (
                      <span className="text-green-500">↑</span>
                    ) : user.change === "down" ? (
                      <span className="text-red-500">↓</span>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

