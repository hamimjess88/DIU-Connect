import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Trophy, Gamepad2, PenSquare, Users, Heart } from "lucide-react"
import MemeFeed from "@/components/meme-feed"
import PollSection from "@/components/poll-section"
import GameSection from "@/components/game-section"
import EventCalendar from "@/components/event-calendar"
import CampusNews from "@/components/campus-news"
import StudyResources from "@/components/study-resources"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="rounded-full bg-primary p-1">
                <Heart className="h-6 w-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">DIU Connect</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#memes" className="text-sm font-medium hover:underline underline-offset-4">
              Memes
            </Link>
            <Link href="#games" className="text-sm font-medium hover:underline underline-offset-4">
              Games
            </Link>
            <Link href="#polls" className="text-sm font-medium hover:underline underline-offset-4">
              Polls
            </Link>
            <Link href="#events" className="text-sm font-medium hover:underline underline-offset-4">
              Events
            </Link>
            <Link href="#news" className="text-sm font-medium hover:underline underline-offset-4">
              News
            </Link>
            <Link href="#resources" className="text-sm font-medium hover:underline underline-offset-4">
              Resources
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" className="hidden md:flex">
              Create Post
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@student" />
              <AvatarFallback>ST</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-primary/20 to-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="outline" className="px-3 py-1 text-sm">
                  For DIU Students Only
                </Badge>
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
                  Connect, Share & Have Fun
                </h1>
                <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                  Your ultimate platform to connect with fellow DIU students, share memes, play games, and make the most
                  of your university life.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg">Join Now</Button>
                <Button size="lg" variant="outline">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="container px-4 py-12 md:px-6" id="memes">
          <div className="mb-10">
            <h2 className="text-3xl font-bold tracking-tight">Trending Memes</h2>
            <p className="text-muted-foreground">The funniest DIU-related memes shared by students</p>
          </div>
          <MemeFeed />
        </section>

        <section className="bg-muted py-12" id="games">
          <div className="container px-4 md:px-6">
            <div className="mb-10">
              <h2 className="text-3xl font-bold tracking-tight">Mini Games</h2>
              <p className="text-muted-foreground">Take a break and have some fun with these mini games</p>
            </div>
            <GameSection />
          </div>
        </section>

        <section className="container px-4 py-12 md:px-6" id="polls">
          <div className="mb-10">
            <h2 className="text-3xl font-bold tracking-tight">Campus Polls</h2>
            <p className="text-muted-foreground">Vote on hot topics and see what other students think</p>
          </div>
          <PollSection />
        </section>

        <section className="bg-muted py-12" id="events">
          <div className="container px-4 md:px-6">
            <div className="mb-10">
              <h2 className="text-3xl font-bold tracking-tight">Academic Calendar</h2>
              <p className="text-muted-foreground">Stay updated with important university dates and events</p>
            </div>
            <EventCalendar />
          </div>
        </section>

        <section className="container px-4 py-12 md:px-6" id="news">
          <div className="mb-10">
            <h2 className="text-3xl font-bold tracking-tight">Campus News</h2>
            <p className="text-muted-foreground">Latest announcements and updates from around the university</p>
          </div>
          <CampusNews />
        </section>

        <section className="bg-muted py-12" id="resources">
          <div className="container px-4 md:px-6">
            <div className="mb-10">
              <h2 className="text-3xl font-bold tracking-tight">Study Resources</h2>
              <p className="text-muted-foreground">
                Access study materials, join groups, and boost your academic performance
              </p>
            </div>
            <StudyResources />
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-primary/10">
          <div className="container px-4 md:px-6">
            <div className="grid gap-10 sm:grid-cols-2 md:grid-cols-4">
              <div className="flex flex-col items-center gap-2 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary">
                  <Users className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold">5,000+</h3>
                <p className="text-muted-foreground">Active Students</p>
              </div>
              <div className="flex flex-col items-center gap-2 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary">
                  <PenSquare className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold">10,000+</h3>
                <p className="text-muted-foreground">Memes Shared</p>
              </div>
              <div className="flex flex-col items-center gap-2 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary">
                  <Gamepad2 className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold">15+</h3>
                <p className="text-muted-foreground">Mini Games</p>
              </div>
              <div className="flex flex-col items-center gap-2 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary">
                  <Trophy className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold">500+</h3>
                <p className="text-muted-foreground">Daily Challenges</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t bg-background">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:gap-8">
          <div className="flex-1 space-y-4">
            <div className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-primary" />
              <span className="text-lg font-bold">DIU Connect</span>
            </div>
            <p className="text-sm text-muted-foreground">
              A fun platform for Daffodil International University students to connect and share experiences.
            </p>
          </div>
          <div className="flex flex-col gap-2 md:flex-row md:gap-12">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Platform</h4>
              <ul className="grid gap-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:underline">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:underline">
                    Features
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:underline">
                    Community Guidelines
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Connect</h4>
              <ul className="grid gap-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:underline">
                    DIU Official
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:underline">
                    Student Council
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:underline">
                    Clubs & Societies
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="border-t py-6">
          <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-center text-sm text-muted-foreground md:text-left">All rights reserved. Tahsin Hamim</p>
            <p className="text-center text-sm text-muted-foreground md:text-left">
              Only this code is open source and free; feel free to use it and expand it as much as you can.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

